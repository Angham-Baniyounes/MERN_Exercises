const express = require('express');
const jwt = require('jsonwebtoken');
const app = express();
const fs = require('fs');
let secret = fs.readFileSync('secretWord.key')
//http://localhost:5000/api
app.get('/api', (req, res) => {
    res.json({
        message: "Hello World"
    });
});
app.post('/api/posts', verifyToken, (req, res) => {
    jwt.verify(req.token, secret, (err, data) => {
        if (err) {
            res.sendStatus(403)
        }
        res.json({
            message: 'post created ....',
            data
        });
    });
});
app.post('/api/login', (req, res) => {
    const user = {
        id: 1,
        username: 'angham',
        password: 'abc123'
    }
    jwt.sign({ user }, secret, (err, token) => {
        if (err) {
            res.json({
                message: "username or password not valid"
            })
        }
        res.json({token})
    });
});
function verifyToken(req, res, next) {
    const bearerHeader = req.headers['authorization'];
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(' ');
        const token = bearer[1];
        req.token = token;
        next()
    } else {
        res.sendStatus(403)
    }
    
}
app.listen(5000, () => console.log("server started on port 5000"));