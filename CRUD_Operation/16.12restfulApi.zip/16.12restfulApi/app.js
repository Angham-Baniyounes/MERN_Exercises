const express = require('express');
const app = express();
const mongodb = require('mongodb')
const mongo = mongodb.MongoClient;
const bodyParser = require('body-parser');
app.use(bodyParser.json({type: 'application/json'}))

//get All Data (R : CRUD Operation)
app.get('/listBooks', (req, res)=> {
    mongo.connect("mongodb://localhost:27017", {useNewUrlParser: true}, (err, conn) => {
        if(err)
            return err.message;
        let library = conn.db("Library");
        library.collection("book").find({}).toArray((err, result) => {
            if(err)
                return err.message;
            conn.close();
            res.writeHead(200, {"Content-type": "application/json"});
            res.write(JSON.stringify(result));
            res.end();
        })
    })
});

//add data(C: CRUD Operations)
app.post('/addBook', (req, res)=> {
    mongo.connect("mongodb://localhost:27017", {useNewUrlParser: true}, (err, conn) => {
        if(err)
            return err.message;
        let library = conn.db("Library");
        let newBook = req.body;
        console.log(newBook);
        library.collection("book").insertOne(newBook, (err, result) => {
            if(err)
                return err.message;
            conn.close();
            res.write("{'inserted_id' :" + result.insertedId +"}");
            res.end();
        })
    })
});

//delete data(D: CRUD Operations)
app.delete('/deleteBook', (req, res)=> {
    mongo.connect("mongodb://localhost:27017", {useNewUrlParser: true}, (err, conn) => {
        if(err)
            return err.message;
        let library = conn.db("Library");
        let filter = {_id: new mongodb.ObjectID(req.body._id)};
        console.log(filter);
        library.collection("book").deleteOne(filter, (err, result) => {
            if(err)
                return err.message;
            conn.close();
            res.write("{'deleted' : 'true'}");
            res.end();
        })
    })
});

//Read Data by Id 
app.get('/getBooById/:id', (req, res)=> {
    mongo.connect("mongodb://localhost:27017", {useNewUrlParser: true}, (err, conn) => {
        if(err)
            return err.message;
        let library = conn.db("Library");
        let query = {_id : new mongodb.ObjectID(req.params.id)}
        library.collection("book").find(query).toArray((err, result) => {
            if(err)
                return err.message;
            conn.close();
            res.writeHead(200, {"Content-type": "application/json"});
            res.write(JSON.stringify(result));
            res.end();
        })
    })
});

//Update data(U: CRUD Operations)
app.put('/updateBook/', (req, res)=> {
    mongo.connect("mongodb://localhost:27017", {useNewUrlParser: true},(err, conn) => {
        if(err)
            return err.message;
        try{
            let library = conn.db("Library");
            let condition = req.header.id 
            let newValues = {$set : req.body};
            library.collection("book").updateOne({"_id" :req.headers.id.toString},newValues, (err, result) => {
                if(err)
                    return err.message;
                conn.close();
                res.write("user updated" + " and the new value " + result);
                
                                res.end();
            });
        } catch(error) {
            res.end("{'updated': 'false'}");
        }
    })
});



app.listen(3000, "127.0.0.1")